# react-drop-file-input

    React Drag and Drop file input

# Video tutorial

    https://youtu.be/Aoz0eQAbEUo

# Description

    Build React Drag and Drop file input

# Resource

    Google font: https://fonts.google.com/

    Boxicons: https://boxicons.com/

    Images: https://unsplash.com/

# Preview

!["React Drag and Drop file input"](https://user-images.githubusercontent.com/67447840/135160494-703a6872-3ac9-4030-ae4c-d7771186f58b.jpg "React Drag and Drop file input")
